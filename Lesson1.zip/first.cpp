#include <iostream>

int main() {
    std::cout <<"hello, World!" << std::endl;
    return 0;
}